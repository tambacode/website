
 ### v1.0.6 - 2018-05-25 
 **Changes:** 
 * Fixed form layout issues
 
 ### v1.0.5 - 2018-05-24 
 **Changes:** 
 * Redone the screenshot
* Fixed compatibility problems with Pirate Forms
 
 ### v1.0.4 - 2018-05-22 
 **Changes:** 
 * Update the screenshot
 
 ### v1.0.3 - 2018-05-22 
 **Changes:** 
 * Fixed alignment issues in the contact form
 
 ### v1.0.2 - 2018-05-18 
 **Changes:** 
 * Removed some extra padding from the Big Title subtitle
 
 ### v1.0.1 - 2018-05-18 
 **Changes:** 
 * Added screenshot
 
 ### v1.0.0 - 2018-05-17 
 **Changes:** 
 * Test deployment.
 
